from flask import Flask, render_template, request, redirect, url_for, flash, session, jsonify
from werkzeug.security import generate_password_hash, check_password_hash
from functools import wraps
import psycopg2
from psycopg2.extras import RealDictCursor
import os
from datetime import datetime

app = Flask(__name__)
app.secret_key = os.environ.get('SESSION_SECRET', 'your-secret-key-here')

def get_db_connection():
    conn = psycopg2.connect("dbname='Faculty Leave Management System' user='postgres' password='kashish' host='localhost' port='5432'")
    return conn

def init_db():
    conn = get_db_connection()
    cur = conn.cursor()
    
    cur.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id SERIAL PRIMARY KEY,
            name VARCHAR(255) NOT NULL,
            email VARCHAR(255) UNIQUE NOT NULL,
            password VARCHAR(255) NOT NULL,
            role VARCHAR(50) NOT NULL,
            department VARCHAR(255),
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    cur.execute('''
        CREATE TABLE IF NOT EXISTS leave_types (
            id SERIAL PRIMARY KEY,
            name VARCHAR(100) UNIQUE NOT NULL,
            description TEXT,
            is_active BOOLEAN DEFAULT TRUE,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    cur.execute('''
        CREATE TABLE IF NOT EXISTS leave_requests (
            id SERIAL PRIMARY KEY,
            user_id INTEGER REFERENCES users(id),
            leave_type_id INTEGER REFERENCES leave_types(id),
            start_date DATE NOT NULL,
            end_date DATE NOT NULL,
            reason TEXT NOT NULL,
            status VARCHAR(50) DEFAULT 'Pending',
            admin_comment TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    cur.execute("SELECT COUNT(*) FROM leave_types")
    leave_type_result = cur.fetchone()
    leave_type_count = leave_type_result[0] if leave_type_result else 0
    
    if leave_type_count == 0:
        leave_types = [
            ('Sick Leave', 'For illness or medical appointments'),
            ('Casual Leave', 'For personal reasons and short breaks'),
            ('Earned Leave', 'Accumulated leave earned through service'),
            ('Maternity Leave', 'For maternity purposes'),
            ('Paternity Leave', 'For paternity purposes'),
            ('Medical Leave', 'For extended medical treatment'),
            ('Emergency Leave', 'For urgent and unforeseen circumstances'),
            ('Compensatory Leave', 'Compensation for overtime or weekend work'),
            ('Study Leave', 'For educational and professional development'),
            ('Other', 'Other types of leave')
        ]
        cur.executemany(
            "INSERT INTO leave_types (name, description) VALUES (%s, %s)",
            leave_types
        )
    
    cur.execute("SELECT COUNT(*) FROM users WHERE role = 'admin'")
    result = cur.fetchone()
    admin_count = result[0] if result else 0
    
    if admin_count == 0:
        default_admin_password = generate_password_hash('admin123')
        cur.execute(
            "INSERT INTO users (name, email, password, role, department) VALUES (%s, %s, %s, %s, %s)",
            ('Admin User', 'admin@college.edu', default_admin_password, 'admin', 'Administration')
        )
    
    conn.commit()
    cur.close()
    conn.close()

def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            flash('Please log in to access this page.', 'warning')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function

def admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            flash('Please log in to access this page.', 'warning')
            return redirect(url_for('login'))
        if session.get('role') != 'admin':
            flash('Access denied. Admin privileges required.', 'danger')
            return redirect(url_for('dashboard'))
        return f(*args, **kwargs)
    return decorated_function

@app.route('/')
def index():
    if 'user_id' in session:
        return redirect(url_for('dashboard'))
    return redirect(url_for('login'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')
        
        if not email or not password:
            flash('Please provide both email and password.', 'danger')
            return render_template('login.html')
        
        conn = get_db_connection()
        cur = conn.cursor(cursor_factory=RealDictCursor)
        cur.execute("SELECT * FROM users WHERE email = %s", (email,))
        user = cur.fetchone()
        cur.close()
        conn.close()
        
        if user and check_password_hash(user['password'], password):
            session['user_id'] = user['id']
            session['name'] = user['name']
            session['email'] = user['email']
            session['role'] = user['role']
            flash(f'Welcome back, {user["name"]}!', 'success')
            return redirect(url_for('dashboard'))
        else:
            flash('Invalid email or password.', 'danger')
    
    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        name = request.form.get('name')
        email = request.form.get('email')
        password = request.form.get('password')
        department = request.form.get('department')
        
        if not all([name, email, password, department]):
            flash('Please fill in all fields.', 'danger')
            return render_template('register.html')
        
        conn = get_db_connection()
        cur = conn.cursor()
        
        cur.execute("SELECT * FROM users WHERE email = %s", (email,))
        existing_user = cur.fetchone()
        
        if existing_user:
            flash('Email already registered. Please use a different email.', 'danger')
            cur.close()
            conn.close()
            return redirect(url_for('register'))
        
        hashed_password = generate_password_hash(password)
        cur.execute(
            "INSERT INTO users (name, email, password, role, department) VALUES (%s, %s, %s, %s, %s)",
            (name, email, hashed_password, 'faculty', department)
        )
        conn.commit()
        cur.close()
        conn.close()
        
        flash('Registration successful! Please log in.', 'success')
        return redirect(url_for('login'))
    
    return render_template('register.html')

@app.route('/logout')
def logout():
    session.clear()
    flash('You have been logged out successfully.', 'info')
    return redirect(url_for('login'))

@app.route('/dashboard')
@login_required
def dashboard():
    if session.get('role') == 'admin':
        return redirect(url_for('admin_dashboard'))
    
    conn = get_db_connection()
    cur = conn.cursor(cursor_factory=RealDictCursor)
    cur.execute('''
        SELECT lr.*, lt.name as leave_type_name 
        FROM leave_requests lr 
        JOIN leave_types lt ON lr.leave_type_id = lt.id 
        WHERE lr.user_id = %s 
        ORDER BY lr.created_at DESC
    ''', (session['user_id'],))
    leave_requests = cur.fetchall()
    cur.close()
    conn.close()
    
    return render_template('faculty_dashboard.html', leave_requests=leave_requests)

@app.route('/submit_leave', methods=['GET', 'POST'])
@login_required
def submit_leave():
    conn = get_db_connection()
    cur = conn.cursor(cursor_factory=RealDictCursor)
    
    if request.method == 'POST':
        leave_type_id = request.form.get('leave_type_id')
        start_date = request.form.get('start_date')
        end_date = request.form.get('end_date')
        reason = request.form.get('reason')
        
        cur.execute(
            "INSERT INTO leave_requests (user_id, leave_type_id, start_date, end_date, reason) VALUES (%s, %s, %s, %s, %s)",
            (session['user_id'], leave_type_id, start_date, end_date, reason)
        )
        conn.commit()
        cur.close()
        conn.close()
        
        flash('Leave request submitted successfully!', 'success')
        return redirect(url_for('dashboard'))
    
    cur.execute("SELECT * FROM leave_types WHERE is_active = TRUE ORDER BY name")
    leave_types = cur.fetchall()
    cur.close()
    conn.close()
    
    return render_template('submit_leave.html', leave_types=leave_types)

@app.route('/admin/dashboard')
@admin_required
def admin_dashboard():
    status_filter = request.args.get('status', 'all')
    
    conn = get_db_connection()
    cur = conn.cursor(cursor_factory=RealDictCursor)
    
    if status_filter == 'all':
        cur.execute('''
            SELECT lr.*, u.name as faculty_name, u.email as faculty_email, u.department, lt.name as leave_type_name 
            FROM leave_requests lr 
            JOIN users u ON lr.user_id = u.id 
            JOIN leave_types lt ON lr.leave_type_id = lt.id 
            ORDER BY lr.created_at DESC
        ''')
    else:
        cur.execute('''
            SELECT lr.*, u.name as faculty_name, u.email as faculty_email, u.department, lt.name as leave_type_name 
            FROM leave_requests lr 
            JOIN users u ON lr.user_id = u.id 
            JOIN leave_types lt ON lr.leave_type_id = lt.id 
            WHERE lr.status = %s 
            ORDER BY lr.created_at DESC
        ''', (status_filter.capitalize(),))
    
    leave_requests = cur.fetchall()
    cur.close()
    conn.close()
    
    return render_template('admin_dashboard.html', leave_requests=leave_requests, status_filter=status_filter)

@app.route('/admin/update_leave/<int:leave_id>', methods=['POST'])
@admin_required
def update_leave(leave_id):
    action = request.form.get('action')
    comment = request.form.get('comment', '')
    
    status = 'Approved' if action == 'approve' else 'Rejected'
    
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute(
        "UPDATE leave_requests SET status = %s, admin_comment = %s, updated_at = %s WHERE id = %s",
        (status, comment, datetime.now(), leave_id)
    )
    conn.commit()
    cur.close()
    conn.close()
    
    flash(f'Leave request {status.lower()} successfully!', 'success')
    return redirect(url_for('admin_dashboard'))

@app.route('/leave_history')
@login_required
def leave_history():
    search_query = request.args.get('search', '')
    start_date = request.args.get('start_date', '')
    end_date = request.args.get('end_date', '')
    
    conn = get_db_connection()
    cur = conn.cursor(cursor_factory=RealDictCursor)
    
    if session.get('role') == 'admin':
        query = '''
            SELECT lr.*, u.name as faculty_name, u.email as faculty_email, u.department, lt.name as leave_type_name 
            FROM leave_requests lr 
            JOIN users u ON lr.user_id = u.id 
            JOIN leave_types lt ON lr.leave_type_id = lt.id 
            WHERE 1=1
        '''
        params = []
        
        if search_query:
            query += " AND (u.name ILIKE %s OR u.email ILIKE %s OR u.department ILIKE %s)"
            search_pattern = f'%{search_query}%'
            params.extend([search_pattern, search_pattern, search_pattern])
        
        if start_date:
            query += " AND lr.start_date >= %s"
            params.append(start_date)
        
        if end_date:
            query += " AND lr.end_date <= %s"
            params.append(end_date)
        
        query += " ORDER BY lr.created_at DESC"
        cur.execute(query, params)
    else:
        query = '''
            SELECT lr.*, lt.name as leave_type_name 
            FROM leave_requests lr 
            JOIN leave_types lt ON lr.leave_type_id = lt.id 
            WHERE lr.user_id = %s
        '''
        params = [session['user_id']]
        
        if start_date:
            query += " AND lr.start_date >= %s"
            params.append(start_date)
        
        if end_date:
            query += " AND lr.end_date <= %s"
            params.append(end_date)
        
        query += " ORDER BY lr.created_at DESC"
        cur.execute(query, params)
    
    leave_requests = cur.fetchall()
    cur.close()
    conn.close()
    
    return render_template('leave_history.html', leave_requests=leave_requests, 
                         search_query=search_query, start_date=start_date, end_date=end_date)

if __name__ == '__main__':
    init_db()
    app.run(host='0.0.0.0', port=5000, debug=True)
