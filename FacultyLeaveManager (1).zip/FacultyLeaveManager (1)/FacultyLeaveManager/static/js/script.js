document.addEventListener('DOMContentLoaded', function() {
    const alerts = document.querySelectorAll('.alert');
    alerts.forEach(alert => {
        setTimeout(() => {
            alert.style.opacity = '0';
            setTimeout(() => {
                alert.style.display = 'none';
            }, 300);
        }, 5000);
    });

    const dateInputs = document.querySelectorAll('input[type="date"]');
    dateInputs.forEach(input => {
        if (!input.value) {
            const today = new Date().toISOString().split('T')[0];
            if (input.hasAttribute('min') && !input.getAttribute('min')) {
                input.setAttribute('min', today);
            }
        }
    });

    const tables = document.querySelectorAll('.data-table');
    tables.forEach(table => {
        const rows = table.querySelectorAll('tbody tr');
        rows.forEach(row => {
            row.addEventListener('click', function(e) {
                if (!e.target.classList.contains('btn-action') && !e.target.tagName === 'BUTTON') {
                    const reasonCell = this.querySelector('.reason-cell');
                    if (reasonCell) {
                        if (reasonCell.style.whiteSpace === 'normal') {
                            reasonCell.style.whiteSpace = 'nowrap';
                            reasonCell.style.overflow = 'hidden';
                            reasonCell.style.textOverflow = 'ellipsis';
                        } else {
                            reasonCell.style.whiteSpace = 'normal';
                            reasonCell.style.overflow = 'visible';
                            reasonCell.style.textOverflow = 'clip';
                        }
                    }
                }
            });
        });
    });
});

function validateLeaveForm() {
    const startDate = document.getElementById('start_date').value;
    const endDate = document.getElementById('end_date').value;
    
    if (new Date(endDate) < new Date(startDate)) {
        alert('End date cannot be earlier than start date');
        return false;
    }
    
    return true;
}

function confirmAction(message) {
    return confirm(message);
}
