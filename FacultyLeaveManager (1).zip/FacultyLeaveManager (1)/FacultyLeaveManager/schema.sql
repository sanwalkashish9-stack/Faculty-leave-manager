-- Faculty Leave Management System - Database Schema
-- PostgreSQL Database Schema

-- Drop tables if they exist (for clean installation)
DROP TABLE IF EXISTS leave_requests CASCADE;
DROP TABLE IF EXISTS leave_types CASCADE;
DROP TABLE IF EXISTS users CASCADE;

-- Create users table
CREATE TABLE users (
    id SERIAL PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    role VARCHAR(50) NOT NULL CHECK (role IN ('faculty', 'admin')),
    department VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create leave_types table
CREATE TABLE leave_types (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) UNIQUE NOT NULL,
    description TEXT,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create leave_requests table
CREATE TABLE leave_requests (
    id SERIAL PRIMARY KEY,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    leave_type_id INTEGER NOT NULL REFERENCES leave_types(id) ON DELETE RESTRICT,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    reason TEXT NOT NULL,
    status VARCHAR(50) DEFAULT 'Pending' CHECK (status IN ('Pending', 'Approved', 'Rejected')),
    admin_comment TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT valid_date_range CHECK (end_date >= start_date)
);

-- Create indexes for better query performance
CREATE INDEX idx_leave_requests_user_id ON leave_requests(user_id);
CREATE INDEX idx_leave_requests_leave_type_id ON leave_requests(leave_type_id);
CREATE INDEX idx_leave_requests_status ON leave_requests(status);
CREATE INDEX idx_leave_requests_created_at ON leave_requests(created_at DESC);
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_role ON users(role);

-- Insert default leave types
INSERT INTO leave_types (name, description) VALUES
    ('Sick Leave', 'For illness or medical appointments'),
    ('Casual Leave', 'For personal reasons and short breaks'),
    ('Earned Leave', 'Accumulated leave earned through service'),
    ('Maternity Leave', 'For maternity purposes'),
    ('Paternity Leave', 'For paternity purposes'),
    ('Medical Leave', 'For extended medical treatment'),
    ('Emergency Leave', 'For urgent and unforeseen circumstances'),
    ('Compensatory Leave', 'Compensation for overtime or weekend work'),
    ('Study Leave', 'For educational and professional development'),
    ('Other', 'Other types of leave');

-- Insert default admin user
-- Password: admin123 (hashed using Werkzeug's generate_password_hash)
-- Note: Change this password after first login in production
INSERT INTO users (name, email, password, role, department) VALUES
    ('Admin User', 'admin@college.edu', 'scrypt:32768:8:1$jYQZ8gXRkN7pqE0V$f8e5a8a5b5d5c5d5e5f5a5b5c5d5e5f5a5b5c5d5e5f5a5b5c5d5e5f5a5b5c5d5e5f5a5b5c5d5e5f5a5b5c5d5e5f5', 'admin', 'Administration');

-- Comments for documentation
COMMENT ON TABLE users IS 'Stores user accounts for faculty and administrators';
COMMENT ON TABLE leave_types IS 'Defines available leave types in the system';
COMMENT ON TABLE leave_requests IS 'Stores all leave requests submitted by faculty members';

COMMENT ON COLUMN users.role IS 'User role: faculty or admin';
COMMENT ON COLUMN leave_requests.status IS 'Request status: Pending, Approved, or Rejected';
COMMENT ON COLUMN leave_types.is_active IS 'Flag to enable/disable leave types without deleting them';
